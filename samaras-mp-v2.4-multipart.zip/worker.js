/**
 * समरस मध्यप्रदेश — V2.4
 * Authorized Google uploader + Area Policy + R2 Multipart Upload
 *
 * Bindings:
 *   R2_BUCKET    -> R2 bucket
 *   METADATA_KV  -> KV namespace
 *
 * Secrets / vars:
 *   ADMIN_SECRET
 *   GOOGLE_CLIENT_ID
 *   GOOGLE_JWKS_URL (optional; defaults to Google)
 *
 * KV:
 *   uploader:<email> -> uploader profile JSON
 *   mpu:<uploadId>   -> upload session JSON
 *   part:<uploadId>:<n> -> {"size": number}
 */

const DEFAULT_JWKS_URL = "https://www.googleapis.com/oauth2/v3/certs";
const MAX_HARD_MB = 500;
const MIN_PART = 5 * 1024 * 1024;
const DEFAULT_PART = 10 * 1024 * 1024;

const ALLOWED_TYPES = new Set([
  "image/jpeg","image/png","image/webp","image/gif",
  "video/mp4","video/quicktime","video/webm","video/3gpp","video/3gpp2",
]);

const json = (data, status=200, extra={}) =>
  new Response(JSON.stringify(data), {
    status,
    headers: {"content-type":"application/json; charset=utf-8", ...extra}
  });

const normEmail = e => String(e || "").trim().toLowerCase();

function cors(request) {
  const origin = request.headers.get("Origin") || "";
  const allowed = [
    "https://ajaysingh132.github.io",
    "http://localhost:5500",
    "http://127.0.0.1:5500"
  ];
  return {
    "Access-Control-Allow-Origin": allowed.includes(origin) ? origin : "null",
    "Access-Control-Allow-Credentials": "true",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "GET, POST, PUT, OPTIONS",
    "Vary": "Origin"
  };
}

async function readJson(request) {
  try { return await request.json(); }
  catch { return null; }
}

function safeKey(s) {
  return String(s || "").replace(/[^a-zA-Z0-9._@-]/g, "_").slice(0,180);
}

function policyFor(profile) {
  const maxFileSizeMB = Number(profile.maxFileSizeMB);
  const dailyQuotaMB = Number(profile.dailyQuotaMB);
  const dailyFileLimit = Number(profile.dailyFileLimit);
  if (![100,200,300,400,500].includes(maxFileSizeMB)) throw new Error("Invalid area policy");
  if (!Number.isFinite(dailyQuotaMB) || dailyQuotaMB <= 0) throw new Error("Invalid daily quota");
  if (!Number.isFinite(dailyFileLimit) || dailyFileLimit <= 0) throw new Error("Invalid daily file limit");
  return { maxFileSizeMB, dailyQuotaMB, dailyFileLimit };
}

async function getUploader(env, email) {
  const raw = await env.METADATA_KV.get(`uploader:${normEmail(email)}`);
  if (!raw) return null;
  try { return JSON.parse(raw); } catch { return null; }
}

function b64urlToBytes(s) {
  s = s.replace(/-/g, "+").replace(/_/g, "/");
  while (s.length % 4) s += "=";
  const bin = atob(s);
  return Uint8Array.from(bin, c => c.charCodeAt(0));
}

function decodeJwtPart(s) {
  return JSON.parse(new TextDecoder().decode(b64urlToBytes(s)));
}

async function getGoogleKeys(env) {
  const url = env.GOOGLE_JWKS_URL || DEFAULT_JWKS_URL;
  const cacheKey = new Request(url);
  const cache = caches.default;
  const cached = await cache.match(cacheKey);
  if (cached) return cached.json();
  const res = await fetch(url);
  if (!res.ok) throw new Error("Google signing keys unavailable");
  const clone = res.clone();
  clone.headers.set("Cache-Control", "public, max-age=3600");
  await cache.put(cacheKey, clone);
  return res.json();
}

async function verifyGoogleToken(token, env) {
  if (!token) throw new Error("Google login required");
  const pieces = token.split(".");
  if (pieces.length !== 3) throw new Error("Invalid Google token");

  const header = decodeJwtPart(pieces[0]);
  const payload = decodeJwtPart(pieces[1]);

  if (header.alg !== "RS256" || !header.kid) throw new Error("Unsupported Google token");
  if (!["accounts.google.com","https://accounts.google.com"].includes(payload.iss))
    throw new Error("Invalid token issuer");
  if (env.GOOGLE_CLIENT_ID && payload.aud !== env.GOOGLE_CLIENT_ID)
    throw new Error("Google account is not authorized for this site");
  if (!payload.email || payload.email_verified !== true)
    throw new Error("Verified Google email required");
  if (!payload.exp || payload.exp < Math.floor(Date.now()/1000))
    throw new Error("Google login expired");

  const jwks = await getGoogleKeys(env);
  const jwk = jwks.keys.find(k => k.kid === header.kid);
  if (!jwk) throw new Error("Google signing key not found");

  const key = await crypto.subtle.importKey(
    "jwk", jwk, {name:"RSASSA-PKCS1-v1_5", hash:"SHA-256"}, false, ["verify"]
  );
  const data = new TextEncoder().encode(`${pieces[0]}.${pieces[1]}`);
  const sig = b64urlToBytes(pieces[2]);
  const ok = await crypto.subtle.verify("RSASSA-PKCS1-v1_5", key, sig, data);
  if (!ok) throw new Error("Google token signature invalid");

  return {
    email: normEmail(payload.email),
    name: payload.name || payload.email,
    sub: payload.sub
  };
}

function bearer(request) {
  const h = request.headers.get("Authorization") || "";
  return h.startsWith("Bearer ") ? h.slice(7) : "";
}

async function authUploader(request, env) {
  const identity = await verifyGoogleToken(bearer(request), env);
  const profile = await getUploader(env, identity.email);
  if (!profile || profile.status !== "active")
    throw new Error("यह Google account अधिकृत uploader नहीं है");
  return {identity, profile, policy: policyFor(profile)};
}

async function adminOk(request, env) {
  const secret = bearer(request);
  return !!secret && !!env.ADMIN_SECRET && secret === env.ADMIN_SECRET;
}

async function todayKey(email) {
  const d = new Date().toISOString().slice(0,10);
  return `usage:${d}:${normEmail(email)}`;
}

async function getUsage(env, email) {
  const raw = await env.METADATA_KV.get(await todayKey(email));
  return raw ? JSON.parse(raw) : {bytes:0, files:0};
}

/*
 * KV is intentionally used for the first MVP. For very high concurrency,
 * replace this quota counter with a Durable Object or D1 transaction.
 */
async function reserveQuota(env, email, bytes, policy) {
  const key = await todayKey(email);
  const usage = await getUsage(env, email);
  const quota = policy.dailyQuotaMB * 1024 * 1024;
  if (usage.files >= policy.dailyFileLimit)
    throw new Error(`आज की अधिकतम ${policy.dailyFileLimit} फाइलें पूरी हो चुकी हैं`);
  if (usage.bytes + bytes > quota)
    throw new Error(`आज का upload quota ${policy.dailyQuotaMB} MB है`);
  const next = {bytes: usage.bytes + bytes, files: usage.files + 1};
  await env.METADATA_KV.put(key, JSON.stringify(next), {expirationTtl: 172800});
  return next;
}

function isAllowedType(type) {
  return ALLOWED_TYPES.has(String(type || "").toLowerCase());
}

function makeId() {
  return "SMMP-" + Date.now().toString(36).toUpperCase() + "-" +
    crypto.randomUUID().slice(0,8).toUpperCase();
}

async function handleCreate(request, env) {
  const {identity, profile, policy} = await authUploader(request, env);
  const body = await readJson(request);
  if (!body) return json({error:"Invalid JSON"},400);
  const fileSize = Number(body.fileSize);
  const fileType = String(body.fileType || "").toLowerCase();
  if (!Number.isSafeInteger(fileSize) || fileSize <= 0)
    return json({error:"Invalid file size"},400);
  if (fileSize > policy.maxFileSizeMB * 1024 * 1024)
    return json({error:`आपके क्षेत्र की सीमा ${policy.maxFileSizeMB} MB है`},413);
  if (fileSize > MAX_HARD_MB * 1024 * 1024)
    return json({error:"Hard limit 500 MB"},413);
  if (!isAllowedType(fileType))
    return json({error:"यह media type स्वीकार नहीं है"},415);

  // Reserve quota before upload. If an upload is abandoned, the MVP quota
  // remains reserved; an admin can reset it later.
  await reserveQuota(env, identity.email, fileSize, policy);

  const uploadId = makeId();
  const ext = (String(body.filename || "").split(".").pop() || "bin")
    .replace(/[^a-zA-Z0-9]/g,"").slice(0,8).toLowerCase();
  const key = `00_PENDING_REVIEW/${new Date().toISOString().slice(0,10)}/${uploadId}.${ext}`;

  const mpu = await env.R2_BUCKET.createMultipartUpload(key, {
    httpMetadata: {contentType: fileType}
  });

  const session = {
    uploadId, key, email: identity.email, googleSub: identity.sub,
    uploaderName: profile.name || identity.name,
    fileSize, fileType, filename: body.filename || "",
    district: profile.district || "",
    assembly: profile.assembly || "",
    mandal: profile.mandal || "",
    ward: profile.ward || "",
    area: profile.area || "",
    role: profile.role || "",
    event: body.event || "",
    location: body.location || "",
    eventDate: body.eventDate || "",
    description: body.description || "",
    createdAt: new Date().toISOString(),
    status: "uploading",
    maxFileSizeMB: policy.maxFileSizeMB,
    dailyQuotaMB: policy.dailyQuotaMB
  };
  await env.METADATA_KV.put(`mpu:${mpu.uploadId}`, JSON.stringify(session), {expirationTtl:604800});

  return json({
    uploadId: mpu.uploadId, key,
    partSize: DEFAULT_PART,
    maxFileSizeMB: policy.maxFileSizeMB,
    profile: {
      name: session.uploaderName, email: identity.email,
      district: session.district, assembly: session.assembly,
      mandal: session.mandal, ward: session.ward, area: session.area,
      role: session.role
    }
  }, 201);
}

async function getSession(env, uploadId) {
  const raw = await env.METADATA_KV.get(`mpu:${uploadId}`);
  if (!raw) return null;
  try { return JSON.parse(raw); } catch { return null; }
}

async function ensureSessionOwner(request, env, session) {
  const identity = await verifyGoogleToken(bearer(request), env);
  if (identity.email !== session.email) throw new Error("इस upload की अनुमति आपके account को नहीं है");
  return identity;
}

async function handlePart(request, env, url) {
  const uploadId = url.searchParams.get("uploadId");
  const partNumber = Number(url.searchParams.get("partNumber"));
  if (!uploadId || !Number.isInteger(partNumber) || partNumber < 1 || partNumber > 10000)
    return json({error:"Invalid multipart parameters"},400);
  if (!request.body) return json({error:"Missing part body"},400);

  const session = await getSession(env, uploadId);
  if (!session) return json({error:"Upload session नहीं मिली या समाप्त हो गई"},404);
  await ensureSessionOwner(request, env, session);

  const upload = env.R2_BUCKET.resumeMultipartUpload(session.key, uploadId);
  const part = await upload.uploadPart(partNumber, request.body);

  const len = Number(request.headers.get("Content-Length") || 0);
  await env.METADATA_KV.put(
    `part:${uploadId}:${partNumber}`,
    JSON.stringify({size:len, etag:part.etag}),
    {expirationTtl:604800}
  );
  return json(part);
}

async function handleComplete(request, env, url) {
  const uploadId = url.searchParams.get("uploadId");
  if (!uploadId) return json({error:"Missing uploadId"},400);
  const session = await getSession(env, uploadId);
  if (!session) return json({error:"Upload session नहीं मिली"},404);
  await ensureSessionOwner(request, env, session);

  const body = await readJson(request);
  if (!body || !Array.isArray(body.parts) || body.parts.length < 1)
    return json({error:"Uploaded parts missing"},400);

  const parts = body.parts.map(p => ({
    partNumber:Number(p.partNumber), etag:String(p.etag)
  })).sort((a,b)=>a.partNumber-b.partNumber);

  if (parts.some((p,i)=>p.partNumber !== i+1))
    return json({error:"Multipart parts क्रम में नहीं हैं"},400);

  const upload = env.R2_BUCKET.resumeMultipartUpload(session.key, uploadId);
  try {
    const obj = await upload.complete(parts);
    session.status = "pending_review";
    session.completedAt = new Date().toISOString();
    session.etag = obj.httpEtag;
    await env.METADATA_KV.put(`pending:${uploadId}`, JSON.stringify(session));
    await env.METADATA_KV.delete(`mpu:${uploadId}`);
    return json({ok:true, uploadId, status:"pending_review", key:session.key});
  } catch (e) {
    return json({error:"R2 multipart complete failed", detail:String(e)},400);
  }
}

async function handleAbort(request, env, url) {
  const uploadId = url.searchParams.get("uploadId");
  const session = await getSession(env, uploadId);
  if (!session) return json({ok:true});
  await ensureSessionOwner(request, env, session);
  try {
    await env.R2_BUCKET.resumeMultipartUpload(session.key, uploadId).abort();
  } catch {}
  await env.METADATA_KV.delete(`mpu:${uploadId}`);
  return json({ok:true});
}

async function handleProfile(request, env) {
  const {identity, profile, policy} = await authUploader(request, env);
  return json({
    authorized:true,
    identity:{email:identity.email, name:identity.name},
    profile,
    policy
  });
}

async function handleAdmin(request, env, url) {
  if (!(await adminOk(request, env))) return json({error:"Admin authorization required"},401);
  if (request.method !== "POST") return json({error:"POST required"},405);
  const body = await readJson(request);
  if (!body || !body.email) return json({error:"email required"},400);
  const email = normEmail(body.email);
  const allowed = [100,200,300,400,500];
  const max = Number(body.maxFileSizeMB);
  if (!allowed.includes(max)) return json({error:"maxFileSizeMB must be 100/200/300/400/500"},400);
  const profile = {
    email,
    name: String(body.name || email).slice(0,120),
    mobile: String(body.mobile || "").slice(0,20),
    district: String(body.district || "").slice(0,80),
    assembly: String(body.assembly || "").slice(0,100),
    mandal: String(body.mandal || "").slice(0,100),
    ward: String(body.ward || "").slice(0,100),
    area: String(body.area || "").slice(0,150),
    role: String(body.role || "कार्यकर्ता").slice(0,80),
    maxFileSizeMB:max,
    dailyQuotaMB:Number(body.dailyQuotaMB || max*5),
    dailyFileLimit:Number(body.dailyFileLimit || 5),
    status: body.status === "suspended" ? "suspended" : "active",
    updatedAt:new Date().toISOString()
  };
  await env.METADATA_KV.put(`uploader:${email}`, JSON.stringify(profile));
  return json({ok:true, profile});
}

export default {
  async fetch(request, env) {
    const headers = cors(request);
    if (request.method === "OPTIONS") return new Response(null,{status:204,headers});
    try {
      const url = new URL(request.url);
      const p = url.pathname;
      let response;

      if (p === "/health") response = json({ok:true, service:"samaras-mp-v2"});
      else if (p === "/profile" && request.method === "GET") response = await handleProfile(request,env);
      else if (p === "/mpu/create" && request.method === "POST") response = await handleCreate(request,env);
      else if (p === "/mpu/part" && request.method === "PUT") response = await handlePart(request,env,url);
      else if (p === "/mpu/complete" && request.method === "POST") response = await handleComplete(request,env,url);
      else if (p === "/mpu/abort" && request.method === "POST") response = await handleAbort(request,env,url);
      else if (p === "/admin/uploader") response = await handleAdmin(request,env,url);
      else response = json({error:"Not found"},404);

      Object.entries(headers).forEach(([k,v])=>response.headers.set(k,v));
      return response;
    } catch (e) {
      const response = json({error:e.message || "Server error"},400);
      Object.entries(headers).forEach(([k,v])=>response.headers.set(k,v));
      return response;
    }
  }
};
