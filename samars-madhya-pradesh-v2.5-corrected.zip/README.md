# समरस मध्यप्रदेश — V2.5

यह corrected package GitHub Pages + Cloudflare Worker + R2 + KV architecture के लिए है।

## GitHub Pages
- मुख्य file: `index.html`
- upload page: `upload.html`
- पुराने `Index.html` को हटाया जा सकता है, लेकिन पहले `index.html` प्रकाशित होने की पुष्टि करें।

## Backend
- `worker.js` Cloudflare Worker है।
- R2 में media रखा जाएगा।
- KV में uploader registry, upload sessions और review metadata रखा जाएगा।
- Google Identity Services ID token को Worker सत्यापित करता है।
- केवल active/pregistered uploader upload कर सकता है।

## Area limits
100 / 200 / 300 / 400 / 500 MB प्रति file.
Daily quota और daily file limit भी uploader profile में निर्धारित हैं।

## जरूरी configuration
`upload.html` में:
- `YOUR_GOOGLE_CLIENT_ID`
- `YOUR_WORKER_URL`

Worker में:
- `GOOGLE_CLIENT_ID`
- R2 binding `R2_BUCKET`
- KV binding `METADATA_KV`
- secret `ADMIN_SECRET`

## परीक्षण क्रम
1. Worker `/health` खोलें।
2. Admin से एक test uploader register करें।
3. Google login करें।
4. 1–2 MB photo upload करें।
5. फिर छोटा video test करें।
6. सफल होने के बाद 100/200/300/400/500 MB area policy test करें।

> यह package configuration placeholders के साथ है; वास्तविक Google Client ID, Worker URL, KV ID और Admin Secret बिना backend को production में चालू नहीं किया जाना चाहिए।
