const JSON_HEADERS = {
  "content-type": "application/json; charset=utf-8",
  "access-control-allow-origin": "*",
  "access-control-allow-headers": "Authorization, Content-Type",
  "access-control-allow-methods": "GET,POST,PUT,OPTIONS"
};

function json(data, status=200) {
  return new Response(JSON.stringify(data), {status, headers: JSON_HEADERS});
}
function bearer(req) {
  const h = req.headers.get("Authorization") || "";
  return h.startsWith("Bearer ") ? h.slice(7) : "";
}
async function googleIdentity(idToken, clientId) {
  if (!idToken || !clientId) throw new Error("Google authentication configuration missing");
  const r = await fetch("https://oauth2.googleapis.com/tokeninfo?id_token=" + encodeURIComponent(idToken));
  if (!r.ok) throw new Error("Google token invalid");
  const d = await r.json();
  if (d.aud !== clientId) throw new Error("Google client mismatch");
  if (d.email_verified !== "true") throw new Error("Google email is not verified");
  return {email:d.email, name:d.name || d.email};
}
async function auth(req, env) {
  const id = await googleIdentity(bearer(req), env.GOOGLE_CLIENT_ID);
  const key = "uploader:" + id.email.toLowerCase();
  const profile = await env.METADATA_KV.get(key, "json");
  if (!profile || profile.status !== "active") throw new Error("यह Google account अधिकृत uploader नहीं है");
  return {identity:id, profile};
}
function dayKey(email) {
  return "quota:" + new Date().toISOString().slice(0,10) + ":" + email.toLowerCase();
}
function safeName(name) {
  return String(name || "media").replace(/[^a-zA-Z0-9._-]/g, "_").slice(0,160);
}
export default {
  async fetch(req, env) {
    if (req.method === "OPTIONS") return new Response("", {status:204, headers:JSON_HEADERS});
    const url = new URL(req.url);

    try {
      if (url.pathname === "/health") return json({ok:true,service:"samras-mp-worker",version:"2.5"});

      if (url.pathname === "/profile" && req.method === "GET") {
        const a = await auth(req, env);
        return json({identity:a.identity, profile:a.profile, policy:{
          maxFileSizeMB:Number(a.profile.maxFileSizeMB || 100),
          dailyQuotaMB:Number(a.profile.dailyQuotaMB || 500),
          dailyFileLimit:Number(a.profile.dailyFileLimit || 5)
        }});
      }

      if (url.pathname === "/admin/uploader" && req.method === "POST") {
        const secret = bearer(req);
        if (!env.ADMIN_SECRET || secret !== env.ADMIN_SECRET) return json({error:"Admin authorization failed"},401);
        const b = await req.json();
        if (!b.email || !b.name || !b.district || !b.ward || !b.area) return json({error:"email, name, district, ward और area आवश्यक हैं"},400);
        const profile = {
          email:String(b.email).toLowerCase().trim(), name:String(b.name), mobile:String(b.mobile||""),
          district:String(b.district), assembly:String(b.assembly||""), mandal:String(b.mandal||""),
          ward:String(b.ward), area:String(b.area), role:String(b.role||"कार्यकर्ता"),
          maxFileSizeMB:[100,200,300,400,500].includes(Number(b.maxFileSizeMB)) ? Number(b.maxFileSizeMB) : 100,
          dailyQuotaMB:Number(b.dailyQuotaMB||500), dailyFileLimit:Number(b.dailyFileLimit||5),
          status:"active", updatedAt:new Date().toISOString()
        };
        await env.METADATA_KV.put("uploader:"+profile.email, JSON.stringify(profile));
        return json({ok:true, message:"Uploader registered", profile});
      }

      if (url.pathname === "/mpu/create" && req.method === "POST") {
        const a = await auth(req, env);
        const b = await req.json();
        const size = Number(b.fileSize || 0);
        const max = Number(a.profile.maxFileSizeMB || 100) * 1024 * 1024;
        if (!size || size > max) return json({error:`आपके क्षेत्र की अधिकतम सीमा ${a.profile.maxFileSizeMB} MB है`},400);
        if (!/^((image|video)\\/)/.test(String(b.fileType||""))) return json({error:"केवल फोटो/वीडियो स्वीकार हैं"},400);

        const quotaKey = dayKey(a.identity.email);
        const used = await env.METADATA_KV.get(quotaKey, "json") || {bytes:0,files:0};
        const quota = Number(a.profile.dailyQuotaMB || 500) * 1024 * 1024;
        const limit = Number(a.profile.dailyFileLimit || 5);
        if (used.files >= limit || used.bytes + size > quota) return json({error:"आज की निर्धारित upload quota पूरी हो गई है"},429);

        const key = `pending/${a.profile.district}/${a.profile.ward}/${Date.now()}-${safeName(b.filename)}`;
        const mp = await env.R2_BUCKET.createMultipartUpload(key, {
          customMetadata:{
            uploaderEmail:a.identity.email, uploaderName:a.identity.name,
            district:a.profile.district, assembly:a.profile.assembly||"",
            mandal:a.profile.mandal||"", ward:a.profile.ward, area:a.profile.area,
            event:String(b.event||""), location:String(b.location||""), eventDate:String(b.eventDate||""),
            description:String(b.description||""), reviewStatus:"pending"
          }
        });
        const uploadId = crypto.randomUUID();
        await env.METADATA_KV.put("upload:"+uploadId, JSON.stringify({
          r2UploadId:mp.uploadId,key,size,email:a.identity.email,
          createdAt:new Date().toISOString()
        }), {expirationTtl:86400});
        return json({ok:true,uploadId});
      }

      if (url.pathname === "/mpu/part" && req.method === "PUT") {
        const a = await auth(req, env);
        const id = url.searchParams.get("uploadId");
        const n = Number(url.searchParams.get("partNumber"));
        if (!id || !Number.isInteger(n) || n < 1) return json({error:"Invalid part"},400);
        const s = await env.METADATA_KV.get("upload:"+id, "json");
        if (!s || s.email !== a.identity.email) return json({error:"Upload session not found"},404);
        const upload = env.R2_BUCKET.resumeMultipartUpload(s.key, s.r2UploadId);
        const result = await upload.uploadPart(n, req.body);
        return json({ok:true,partNumber:n,etag:result.etag});
      }

      if (url.pathname === "/mpu/complete" && req.method === "POST") {
        const a = await auth(req, env);
        const id = url.searchParams.get("uploadId");
        const s = await env.METADATA_KV.get("upload:"+id, "json");
        if (!s || s.email !== a.identity.email) return json({error:"Upload session not found"},404);
        const b = await req.json();
        if (!Array.isArray(b.parts) || !b.parts.length) return json({error:"Parts missing"},400);
        const upload = env.R2_BUCKET.resumeMultipartUpload(s.key, s.r2UploadId);
        await upload.complete(b.parts.map(p => ({partNumber:Number(p.partNumber),etag:p.etag})));

        const quotaKey = dayKey(a.identity.email);
        const used = await env.METADATA_KV.get(quotaKey, "json") || {bytes:0,files:0};
        used.bytes += s.size; used.files += 1;
        await env.METADATA_KV.put(quotaKey, JSON.stringify(used), {expirationTtl:172800});
        await env.METADATA_KV.put("review:"+id, JSON.stringify({
          uploadId:id,key:s.key,email:a.identity.email,size:s.size,status:"pending_review",
          completedAt:new Date().toISOString()
        }), {expirationTtl:2592000});
        await env.METADATA_KV.delete("upload:"+id);
        return json({ok:true,message:"सामग्री प्राप्त हुई और Pending Review में रखी गई",uploadId:id});
      }

      return json({error:"Not found"},404);
    } catch (e) {
      return json({error:e.message || "Server error"},500);
    }
  }
};